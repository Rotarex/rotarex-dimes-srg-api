# rotarex-api

Async Python client for the Rotarex DIMES SRG API.

## Installation

```bash
pip install rotarex-api
