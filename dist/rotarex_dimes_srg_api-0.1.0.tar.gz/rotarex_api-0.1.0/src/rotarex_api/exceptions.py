class InvalidAuth(Exception):
    """Invalid authentication."""
